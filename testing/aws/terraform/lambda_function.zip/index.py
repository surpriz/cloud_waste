import json

def handler(event, context):
    """Simple Lambda function for testing CutCosts detection."""
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from CutCosts test Lambda!')
    }
